package MAP4LDA;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import models.GibbsSamplingLDA;

import org.apache.commons.io.FileUtils;

import Utility.FuncUtils;
import Utility.LBFGS;
import Utility.OWLQN;
import cc.mallet.optimize.InvalidOptimizableException;
import cc.mallet.optimize.Optimizable;
import cc.mallet.optimize.Optimizer;
import cc.mallet.types.MatrixOps;

/**
 * Implementation of the direct MAP estimation approach using word vectors for
 * LDA topic modeling, as described in:
 * 
 * Dat Quoc Nguyen, Kairit Sirts and Mark Johnson. 2015. Improving Topic
 * Coherence with Latent Feature Word Representations in MAP Estimation for
 * Topic Modeling. In Proceedings of the 13th Annual Workshop of the
 * Australasian Language Technology Association, ALTA 2015, pp. 116-121.
 * 
 * @author: Dat Quoc Nguyen
 */

public class LatentMAPestimator4LDAv1
	implements Optimizable.ByGradientValue
{
	final String folderPath;
	// The id-based corpus converted from the original word-based corpus
	List<List<Integer>> corpus;
	// The list to store the topic associating to every word in the whole corpus
	List<List<Integer>> topicAssignments;
	// The number of document in the corpus
	int numDocuments;
	// The vocabulary to map a word to its id.
	HashMap<String, Integer> word2IdVocabulary;
	// The vocabulary to retrieve a word based on its id.
	HashMap<Integer, String> id2WordVocabulary;
	// The number of unique words in the vocabulary
	int vocaSize;

	int numTopics;

	HashMap<Integer, HashMap<Integer, Integer>> wordDocCounter;
	HashMap<Integer, HashMap<Integer, Integer>> docWordCounter;
	HashMap<Integer, HashMap<Integer, Double>> docWordPros;

	public double[][] topicWordParas;
	public double[][] docTopicParas;

	public double[][] topicWordPros;
	public double[][] docTopicPros;

	public double[] sumExpTopicWordParas;
	public double[] sumExpDocTopicParas;

	public double l2topicWord, l2docTopic;
	public String pathToTrainingCorpus;

	public int numTopWords = 10;

	public String suffix;

	public String corpusStrName;

	int vectorSize;

	double[][] wordVectors, topicVectors;

	double l2Topic;

	public int diffL1Index;

	public String wordVectorFileName;

	public LatentMAPestimator4LDAv1(String pathToCorpus,
		String pathToWordVectorsFile, int inNumTopics, double l2DT,
		double l2TW, double l2t, String inSuffix)
		throws Exception
	{
		this(pathToCorpus, pathToWordVectorsFile, inNumTopics, l2DT, l2TW, l2t,
			inSuffix, null);
	}

	public LatentMAPestimator4LDAv1(String pathToCorpus,
		String pathToWordVectorsFile, int inNumTopics, double l2DT,
		double l2TW, double l2t, String inSuffix, String pathToTAfile)
		throws Exception
	{
		numTopics = inNumTopics;
		word2IdVocabulary = new HashMap<String, Integer>();
		id2WordVocabulary = new HashMap<Integer, String>();

		l2docTopic = l2DT;
		l2topicWord = l2TW;
		l2Topic = l2t;

		suffix = inSuffix;

		// Get the path to folder containing the input training corpus
		folderPath = pathToCorpus.substring(
			0,
			Math.max(pathToCorpus.lastIndexOf("/"),
				pathToCorpus.lastIndexOf("\\")) + 1);

		corpusStrName = pathToCorpus.substring(Math.max(
			pathToCorpus.lastIndexOf("/"), pathToCorpus.lastIndexOf("\\")) + 1);

		pathToTrainingCorpus = pathToCorpus;

		wordVectorFileName = pathToWordVectorsFile.substring(Math.max(
			pathToWordVectorsFile.lastIndexOf("/"),
			pathToWordVectorsFile.lastIndexOf("\\")) + 1);

		// Map words and Ids, create id-based
		System.out.println("Reading corpus: " + pathToCorpus);
		corpus = new ArrayList<List<Integer>>();

		numDocuments = 0;
		int indexWord = -1;
		int numWordsInCorpus = 0;

		try (BufferedReader br = new BufferedReader(
			new FileReader(pathToCorpus))) {
			for (String doc; (doc = br.readLine()) != null;) {
				doc = doc.trim();
				if (doc.length() == 0)
					continue;
				String[] words = doc.split("\\s+");

				// Id-based document
				List<Integer> document = new ArrayList<Integer>();

				for (String word : words) {
					if (word2IdVocabulary.containsKey(word)) {
						document.add(word2IdVocabulary.get(word));
					}
					else {
						indexWord += 1;
						word2IdVocabulary.put(word, indexWord);
						id2WordVocabulary.put(indexWord, word);
						document.add(indexWord);
					}
				}
				numDocuments++;
				corpus.add(document);
				numWordsInCorpus += document.size();
			}
		}

		vocaSize = word2IdVocabulary.size();
		docWordCounter = new HashMap<Integer, HashMap<Integer, Integer>>();
		for (int dIndex = 0; dIndex < numDocuments; dIndex++) {
			int docSize = corpus.get(dIndex).size();

			HashMap<Integer, Integer> wordCounter = new HashMap<Integer, Integer>();
			for (int i = 0; i < docSize; i++) {
				// Get current wordID
				int word = corpus.get(dIndex).get(i);
				int times = 0;
				if (wordCounter.containsKey(word))
					times = wordCounter.get(word);
				times += 1;
				wordCounter.put(word, times);
			}
			docWordCounter.put(dIndex, wordCounter);
		}

		wordDocCounter = new HashMap<Integer, HashMap<Integer, Integer>>();
		for (int d : docWordCounter.keySet()) {
			for (int w : docWordCounter.get(d).keySet()) {
				HashMap<Integer, Integer> hashW = new HashMap<Integer, Integer>();
				if (wordDocCounter.containsKey(w))
					hashW = wordDocCounter.get(w);
				hashW.put(d, docWordCounter.get(d).get(w));
				wordDocCounter.put(w, hashW);
			}
		}

		docWordPros = new HashMap<Integer, HashMap<Integer, Double>>();

		topicWordParas = new double[numTopics][vocaSize];
		docTopicParas = new double[numDocuments][numTopics];

		topicWordPros = new double[numTopics][vocaSize];
		docTopicPros = new double[numDocuments][numTopics];

		sumExpTopicWordParas = new double[numTopics];
		sumExpDocTopicParas = new double[numDocuments];

		System.out.println("Corpus size: " + numDocuments + " docs");
		System.out.println("Vocabuary size: " + vocaSize);
		System.out.println("Number of words per document: "
			+ (numWordsInCorpus * 1.0 / numDocuments));

		System.out.println("\nNumber of topics:  " + numTopics);
		System.out.println("L2 regularizer for doc-topic parameters:  "
			+ l2docTopic);
		System.out.println("L2 regularizer for topic-word parameters:  "
			+ l2topicWord);
		System.out.println("L2 regularizer for topic vector parameters:  "
			+ l2Topic);

		// Initialize parameters...

		wordVectors = initWordVectors(pathToWordVectorsFile);
		topicVectors = new double[numTopics][vectorSize];

		if (pathToTAfile == null) {
			LDAinitialize();
		}
		else
			LDAinitialize(pathToTAfile);

		diffL1Index = numTopics * vocaSize;
	}

	private void LDAinitialize()
		throws Exception
	{
		System.out.println("\n-----\nInitialzing parameters by LDA...");

		double[] multiPros = new double[numTopics];
		for (int i = 0; i < numTopics; i++) {
			multiPros[i] = 1.0 / numTopics;
		}

		double ldaAnpha = 0.1, ldaBeta = 0.01;

		// String ldaSuffix = suffix + "." + corpusStrName + "."
		// + wordVectorFileName + "." + numTopics + "." + l2docTopic + "."
		// + l2topicWord + "." + l2Topic + ".LDA";

		String ldaSuffix = suffix + "." + corpusStrName + "." + numTopics
			+ ".LDA";

		GibbsSamplingLDA lda = new GibbsSamplingLDA(pathToTrainingCorpus,
			numTopics, ldaAnpha, ldaBeta, 2000, 10, ldaSuffix);

		lda.inference();
		lda.writeTopicAssignments();
		lda.writeDocTopicPros();
		lda.writeTopTopicalWords();

		System.out.println("\n-----\nComputing initialized parameters...");

		for (int d = 0; d < numDocuments; d++)
			for (int t = 0; t < numTopics; t++) {
				docTopicParas[d][t] = Math
					.log((lda.docTopicCount[d][t] + lda.alpha)
						/ (lda.sumDocTopicCount[d] + lda.alphaSum));
			}

		for (int t = 0; t < numTopics; t++) {

			for (int w = 0; w < vocaSize; w++) {
				topicWordParas[t][w] = Math
					.log((lda.topicWordCount[t][w] + lda.beta)
						/ (lda.sumTopicWordCount[t] + lda.betaSum));
			}
		}

		System.out.println("Completition of parameter initialization!");
	}

	private void LDAinitialize(String pathToInitTAFile)
		throws Exception
	{
		System.out.println("\nInitialzing parameters by LDA...");

		double[] multiPros = new double[numTopics];
		for (int i = 0; i < numTopics; i++) {
			multiPros[i] = 1.0 / numTopics;
		}

		double ldaAnpha = 0.1, ldaBeta = 0.01;

		String ldaSuffix = suffix + "." + corpusStrName + "."
			+ wordVectorFileName + "." + numTopics + "." + l2docTopic + "."
			+ l2topicWord + "." + l2Topic + ".LDA";

		GibbsSamplingLDA lda = new GibbsSamplingLDA(pathToTrainingCorpus,
			numTopics, ldaAnpha, ldaBeta, 2000, 10, ldaSuffix, pathToInitTAFile);

		// System.out.println("====> " + lda.docTopicCount[127][2]);

		System.out.println("Computing initialized parameters...");

		for (int d = 0; d < numDocuments; d++)
			for (int t = 0; t < numTopics; t++) {
				docTopicParas[d][t] = Math
					.log((lda.docTopicCount[d][t] + lda.alpha)
						/ (lda.sumDocTopicCount[d] + lda.alphaSum));
			}

		for (int t = 0; t < numTopics; t++) {

			for (int w = 0; w < vocaSize; w++) {
				topicWordParas[t][w] = Math
					.log((lda.topicWordCount[t][w] + lda.beta)
						/ (lda.sumTopicWordCount[t] + lda.betaSum));
			}
		}

		System.out.println("Completition of parameter initialization");
	}

	public double[][] initWordVectors(String pathToWordVectorsFile)
		throws Exception
	{
		System.out.println("Reading word vectors from word-vectors file "
			+ pathToWordVectorsFile + "...");

		List<String> vectorLines = FileUtils.readLines(new File(
			pathToWordVectorsFile), "UTF-8");

		vectorSize = vectorLines.get(1).trim().split("\\s+").length - 1;
		double[][] tempWordVectors = new double[vocaSize][vectorSize];

		for (int i = 0; i < vectorLines.size(); i++) {
			String[] elements = vectorLines.get(i).trim().split("\\s+");
			String word = elements[0];
			if (word2IdVocabulary.containsKey(word)) {
				for (int j = 0; j < vectorSize; j++) {
					tempWordVectors[word2IdVocabulary.get(word)][j] = new Double(
						elements[j + 1]);
				}
			}
		}

		// Check whether there is a zero-vector ~ a word do not have vector
		// representation
		for (int i = 0; i < vocaSize; i++) {
			if (MatrixOps.absNorm(tempWordVectors[i]) == 0.0) {
				System.out.println("The word \"" + id2WordVocabulary.get(i)
					+ "\" doesn't have a corresponding vector!!!");
				throw new Exception();
			}
		}

		return tempWordVectors;
	}

	public void setTopicWordParas(double[][] topicWordParas)
		throws Exception
	{
		for (int z = 0; z < numTopics; z++) {
			double max = MatrixOps.max(topicWordParas[z]);
			sumExpTopicWordParas[z] = 0.0;
			for (int w = 0; w < vocaSize; w++) {
				this.topicWordParas[z][w] = topicWordParas[z][w];
				topicWordPros[z][w] = Math.exp(topicWordParas[z][w] - max);
				sumExpTopicWordParas[z] += topicWordPros[z][w];
			}
			if (Double.isInfinite(sumExpTopicWordParas[z]))
				throw new Exception();
			if (sumExpTopicWordParas[z] == 0)
				throw new Exception();
		}

		for (int z = 0; z < numTopics; z++)
			for (int w = 0; w < vocaSize; w++)
				topicWordPros[z][w] = topicWordPros[z][w]
					/ sumExpTopicWordParas[z];
	}

	public void setDocTopicParas(double[][] docTopicParas)
		throws Exception
	{
		for (int d = 0; d < numDocuments; d++) {
			double max = MatrixOps.max(docTopicParas[d]);
			sumExpDocTopicParas[d] = 0.0;
			for (int z = 0; z < numTopics; z++) {
				this.docTopicParas[d][z] = docTopicParas[d][z];
				docTopicPros[d][z] = Math.exp(docTopicParas[d][z] - max);
				sumExpDocTopicParas[d] += docTopicPros[d][z];
			}
			if (Double.isInfinite(sumExpDocTopicParas[d]))
				throw new Exception();// should be rescaled

			if (sumExpDocTopicParas[d] == 0)
				throw new Exception();// should be rescaled
		}

		for (int d = 0; d < numDocuments; d++)
			for (int z = 0; z < numTopics; z++)
				docTopicPros[d][z] = docTopicPros[d][z]
					/ sumExpDocTopicParas[d];
	}

	@Override
	public int getNumParameters()
	{
		// TODO Auto-generated method stub
		return numTopics * (vocaSize + numDocuments) + numTopics * vectorSize;
	}

	@Override
	public double getParameter(int index)
	{
		int temp1 = numTopics * vocaSize;
		int temp2 = numTopics * (vocaSize + numDocuments);

		if (index < temp1)
			return topicWordParas[index / vocaSize][index % vocaSize];
		else if ((temp1 <= index) && (index < temp2)) {
			int newIndex = index - numTopics * vocaSize;
			return docTopicParas[newIndex / numTopics][newIndex % numTopics];
		}
		else {
			index = index - temp2;
			int z = index / vectorSize;
			index = index % vectorSize;
			return topicVectors[z][index];
		}

	}

	@Override
	public void getParameters(double[] paras)
	{
		int temp1 = numTopics * vocaSize;
		int temp2 = numTopics * numDocuments;
		int temp = numTopics * (vocaSize + numDocuments);

		for (int index = 0; index < temp1; index++)
			paras[index] = topicWordParas[index / vocaSize][index % vocaSize];

		for (int index = 0; index < temp2; index++)
			paras[index + temp1] = docTopicParas[index / numTopics][index
				% numTopics];

		for (int index = temp; index < getNumParameters(); index++) {
			int indexTmp = index - temp;
			int z = indexTmp / vectorSize;
			indexTmp = indexTmp % vectorSize;
			paras[index] = topicVectors[z][indexTmp];
		}

	}

	@Override
	public void setParameter(int index, double value)
	{
		int temp1 = numTopics * vocaSize;
		int temp2 = numTopics * (vocaSize + numDocuments);

		if (index < temp1)
			topicWordParas[index / vocaSize][index % vocaSize] = value;
		else if ((temp1 <= index) && (index < temp2)) {
			int newIndex = index - numTopics * vocaSize;
			docTopicParas[newIndex / numTopics][newIndex % numTopics] = value;
		}
		else {
			index = index - temp2;
			int z = index / vectorSize;
			index = index % vectorSize;
			topicVectors[z][index] = value;
		}

	}

	@Override
	public void setParameters(double[] paras)
	{
		int temp1 = numTopics * vocaSize;
		int temp2 = numTopics * numDocuments;
		int temp = numTopics * (vocaSize + numDocuments);

		for (int index = 0; index < temp1; index++)
			topicWordParas[index / vocaSize][index % vocaSize] = paras[index];

		for (int index = 0; index < temp2; index++)
			docTopicParas[index / numTopics][index % numTopics] = paras[index
				+ temp1];

		for (int index = temp; index < getNumParameters(); index++) {
			int indexTmp = index - temp;
			int z = indexTmp / vectorSize;
			indexTmp = indexTmp % vectorSize;
			topicVectors[z][indexTmp] = paras[index];
		}

	}

	@Override
	public double getValue()
	{
		try {
			computePwd();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		double value = 0.0;

		for (int d = 0; d < numDocuments; d++)
			for (int w : docWordCounter.get(d).keySet()) {
				value += docWordCounter.get(d).get(w)
					* Math.log(docWordPros.get(d).get(w));
			}

		double temp = 0.0;
		for (int d = 0; d < numDocuments; d++)
			for (int z = 0; z < numTopics; z++)
				temp += docTopicParas[d][z] * docTopicParas[d][z];
		temp = l2docTopic * temp;
		value = value - temp;

		temp = 0.0;
		for (int z = 0; z < numTopics; z++) {
			for (int w = 0; w < vocaSize; w++)
				temp += topicWordParas[z][w] * topicWordParas[z][w];
			value = value - MatrixOps.twoNormSquared(topicVectors[z]) * l2Topic;
		}

		temp = l2topicWord * temp;
		value = value - temp;

		return value;
	}

	@Override
	public void getValueGradient(double[] buffer)
	{
		try {
			computePwd();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (int i = 0; i < getNumParameters(); i++) {
			buffer[i] = 0.0;
		}

		// n_{d,w}\Pr(z \mid, w, \phi, \theta_d)

		HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>> nProZDW = new HashMap<Integer, HashMap<Integer, HashMap<Integer, Double>>>();

		double[] sum_nProZDW = new double[numTopics];
		for (int z = 0; z < numTopics; z++) {
			double tmp = 0.0;
			HashMap<Integer, HashMap<Integer, Double>> nProZDWz = new HashMap<Integer, HashMap<Integer, Double>>();
			for (int d = 0; d < numDocuments; d++) {
				HashMap<Integer, Double> nProZDWd = new HashMap<Integer, Double>();
				for (int w : docWordCounter.get(d).keySet()) {
					tmp = docWordCounter.get(d).get(w) * topicWordPros[z][w]
						* docTopicPros[d][z] / docWordPros.get(d).get(w);
					nProZDWd.put(w, tmp);
					sum_nProZDW[z] += tmp;
				}
				nProZDWz.put(d, nProZDWd);
			}
			nProZDW.put(z, nProZDWz);
		}

		int index = numTopics * (numDocuments + vocaSize);
		for (int z = 0; z < numTopics; z++) {

			double[] tempVals = new double[vocaSize];
			for (int w = 0; w < vocaSize; w++) {
				double temp = 0.0;
				for (int d : wordDocCounter.get(w).keySet()) {
					temp += nProZDW.get(z).get(d).get(w);
				}
				tempVals[w] = temp;

				buffer[z * vocaSize + w] = temp - sum_nProZDW[z]
					* topicWordPros[z][w] - 2 * l2topicWord
					* topicWordParas[z][w];
			}

			for (int i = 0; i < vectorSize; i++) {
				double temp = 0.0;
				double temp1 = 0.0;
				for (int w = 0; w < vocaSize; w++) {
					temp += wordVectors[w][i] * topicWordPros[z][w];
					temp1 += wordVectors[w][i] * tempVals[w];
				}

				buffer[index + z * vectorSize + i] = temp1 - temp
					* sum_nProZDW[z] - 2 * topicVectors[z][i] * l2Topic;

			}
		}

		int index1 = numTopics * vocaSize;
		for (int d = 0; d < numDocuments; d++)
			for (int z = 0; z < numTopics; z++) {
				double tempdz = 0.0;
				for (int w : docWordCounter.get(d).keySet()) {
					tempdz += nProZDW.get(z).get(d).get(w);
				}
				buffer[d * numTopics + z + index1] = tempdz
					- corpus.get(d).size() * docTopicPros[d][z] - 2
					* l2docTopic * docTopicParas[d][z];
			}

	}

	public void computePwd()
		throws Exception
	{

		for (int z = 0; z < numTopics; z++) {
			sumExpTopicWordParas[z] = 0.0;
			for (int w = 0; w < vocaSize; w++) {

				topicWordPros[z][w] = Math.exp(topicWordParas[z][w]
					+ MatrixOps.dotProduct(topicVectors[z], wordVectors[w]));

				sumExpTopicWordParas[z] += topicWordPros[z][w];
			}
			if (Double.isInfinite(sumExpTopicWordParas[z]))
				throw new Exception();
			if (sumExpTopicWordParas[z] == 0)
				throw new Exception();
		}

		for (int z = 0; z < numTopics; z++)
			for (int w = 0; w < vocaSize; w++)
				topicWordPros[z][w] = topicWordPros[z][w]
					/ sumExpTopicWordParas[z];

		for (int d = 0; d < numDocuments; d++) {
			double max = MatrixOps.max(docTopicParas[d]);
			sumExpDocTopicParas[d] = 0.0;
			for (int z = 0; z < numTopics; z++) {
				docTopicPros[d][z] = Math.exp(docTopicParas[d][z] - max);
				sumExpDocTopicParas[d] += docTopicPros[d][z];
			}
			if (Double.isInfinite(sumExpDocTopicParas[d]))
				throw new Exception();// should be rescaled

			if (sumExpDocTopicParas[d] == 0)
				throw new Exception();// should be rescaled
		}

		for (int d = 0; d < numDocuments; d++)
			for (int z = 0; z < numTopics; z++)
				docTopicPros[d][z] = docTopicPros[d][z]
					/ sumExpDocTopicParas[d];

		for (int d = 0; d < numDocuments; d++) {
			HashMap<Integer, Double> wordPros = new HashMap<Integer, Double>();
			for (int w : docWordCounter.get(d).keySet()) {
				double temp = 0.0;
				for (int z = 0; z < numTopics; z++) {
					temp += topicWordPros[z][w] * docTopicPros[d][z];
				}
				wordPros.put(w, temp);
			}
			docWordPros.put(d, wordPros);
		}
	}

	public void writeDocTopicPro()
		throws Exception
	{
		computePwd();

		BufferedWriter writer = new BufferedWriter(new FileWriter(folderPath
			+ suffix + "." + corpusStrName + "." + wordVectorFileName + "."
			+ numTopics + "." + l2docTopic + "." + l2topicWord + "." + l2Topic
			+ ".LatentMAPv1.theta"));

		for (int d = 0; d < numDocuments; d++) {
			for (int z = 0; z < numTopics; z++) {
				writer.write(docTopicPros[d][z] + " ");
			}
			writer.write("\n");
		}
		writer.close();
	}

	public void writeTopicWordPro()
		throws Exception
	{
		computePwd();

		BufferedWriter writer = new BufferedWriter(new FileWriter(folderPath
			+ suffix + "." + corpusStrName + "." + wordVectorFileName + "."
			+ numTopics + "." + l2docTopic + "." + l2topicWord + "." + l2Topic
			+ ".LatentMAPv1.phi"));

		for (int z = 0; z < numTopics; z++) {
			for (int w = 0; w < vocaSize; w++) {
				writer.write(topicWordPros[z][w] + " ");
			}
			writer.write("\n");
		}
		writer.close();
	}

	public void writeTopLikelyWords()
		throws Exception
	{
		// System.out.println("Getting most likely words...");

		computePwd();

		BufferedWriter writer = new BufferedWriter(new FileWriter(folderPath
			+ suffix + "." + corpusStrName + "." + wordVectorFileName + "."
			+ numTopics + "." + l2docTopic + "." + l2topicWord + "." + l2Topic
			+ ".LatentMAPv1.topWords"));

		for (int z = 0; z < numTopics; z++) {
			writer.write("Topic" + new Integer(z) + ":");

			Map<Integer, Double> wordCount = new TreeMap<Integer, Double>();
			for (int w = 0; w < vocaSize; w++) {
				wordCount.put(w, topicWordPros[z][w]);
			}
			wordCount = FuncUtils.sortByValueDescending(wordCount);

			Set<Integer> mostLikelyWords = wordCount.keySet();
			int count = 0;
			for (Integer index : mostLikelyWords) {
				if (count < numTopWords) {
					// writer.write(" " + id2WordVocabulary.get(index));
					double pro = Math
						.round(topicWordPros[z][index] * 1000000.0) / 1000000.0;
					writer.write(" " + id2WordVocabulary.get(index) + "(" + pro
						+ ")");
					count += 1;
				}
				else {
					writer.write("\n\n");
					break;
				}
			}
		}
		writer.close();
	}

	// Using only L2 regularizer
	public static void run(String pathToCorpus, String inVectorFile,
		int inNumTopics, double l2DT, double l2TW, double l2t, String suffix)
		throws Exception
	{
		boolean check = true;
		while (check) {
			try {

				LatentMAPestimator4LDAv1 maxable = new LatentMAPestimator4LDAv1(
					pathToCorpus, inVectorFile, inNumTopics, l2DT, l2TW, l2t,
					suffix);

				System.out
					.println("Init log likelihood: " + maxable.getValue());

				Optimizer gd2 = new LBFGS(maxable, 0.0001);
				gd2.optimize(1000);
				System.out.println(maxable.getValue());

				maxable.writeDocTopicPro();
				maxable.writeTopLikelyWords();
				// maxable.writeTopicWordPro();

				check = false;

			}
			catch (InvalidOptimizableException e) {
				e.printStackTrace();
				check = true;
			}
		}

	}

	// Using both L1 and L2 regularizers
	public static void run1(String pathToCorpus, String inVectorFile,
		int inNumTopics, double l2DT, double l2TW, double l2t, double l1value,
		String suffix)
		throws Exception
	{
		boolean check = true;

		while (check) {
			try {

				LatentMAPestimator4LDAv1 maxable = new LatentMAPestimator4LDAv1(
					pathToCorpus, inVectorFile, inNumTopics, l2DT, l2TW, l2t,
					suffix);

				System.out
					.println("Init log likelihood: " + maxable.getValue());
				System.out.println("L1 regularizer for topic-word parameters: "
					+ l1value);

				int index = maxable.diffL1Index;

				double[] l1values = new double[maxable.getNumParameters()];
				for (int i = 0; i < l1values.length; i++) {
					if (i < index)
						l1values[i] = l1value;
					else
						l1values[i] = 0.000001;
				}

				Optimizer gd2 = new OWLQN(maxable, l1values);
				gd2.optimize(1000);
				System.out.println(maxable.getValue());

				maxable.writeDocTopicPro();
				maxable.writeTopLikelyWords();
				// maxable.writeTopicWordPro();

				check = false;

			}
			catch (Exception e) {
				e.printStackTrace();
				check = true;
			}
		}

	}

	public static void main(String args[])
		throws Exception
	{
		// run(args[0], args[1], new Integer(args[2]), new Double(args[3]),
		// new Double(args[4]), new Double(args[5]), args[6]);

		run1(args[0], args[1], new Integer(args[2]), new Double(args[3]),
			new Double(args[4]), new Double(args[5]), new Double(args[6]),
			args[7] + "." + args[6]);

	}
}