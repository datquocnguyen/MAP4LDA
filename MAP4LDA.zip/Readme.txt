1. LICENSE

Copyright (C) 2015 by Dat Quoc Nguyen 
dat.nguyen@students.mq.edu.au
Department of Computing, Macquarie University, Australia
	
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

2. OVERVIEW

This program is the implementation of the MAP estimation approach using word vectors for the LDA topic model, as described in the paper:

Dat Quoc Nguyen, Kairit Sirts and Mark Johnson. 2015. Improving Topic Coherence with Latent Feature Word Representations in MAP Estimation for Topic Modeling. In Proceedings of the 13th Annual Workshop of the Australasian Language Technology Association, ALTA 2015, pp. 116-121.

Please cite this paper when using the program to produce published results.

3. USAGE

To run the program:

MAP4LDA$ java -Xmx8G -jar jar/MAP4LDA.jar PATH-TO-TEXT-CORPUS PATH-TO-WORD-VECTORS NUMBER-OF-TOPICS DOCUMENT-TOPIC-L2-REGULARIZER TOPIC-WORD-L2-REGULARIZER TOPIC-VECTOR-L2-REGULARIZER TOPIC-WORD-L1-REGULARIZER EXPERIMENT-NAME

(Here, L1 regularizers for document-topic parameters and topic parameters are set to 0.000001 by default!)

Noted that the actual command starts from java. Here MAP4LDA$ is simply used to denote the root source folder MAP4LDA.

Example: MAP4LDA$ java -Xmx8G -jar jar/MAP4LDA.jar N20/MAP_N20.txt.Preprocessed.CONTENT N20/MAP.N20.c0.s25.w10.n0.h1.w2v 20 0.01 0.1 0.01 0.01 testRun

If you prefer to not using L1 regularizers, simply uncomment the code lines 839-840 and comment the code lines 842-844 in the source file "LatentMAPestimator4LDAv1.java", and then using `ant` to recompile the program. 